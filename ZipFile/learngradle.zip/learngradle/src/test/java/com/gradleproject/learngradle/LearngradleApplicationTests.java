package com.gradleproject.learngradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearngradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
