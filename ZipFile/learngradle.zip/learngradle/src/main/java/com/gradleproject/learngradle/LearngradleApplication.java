package com.gradleproject.learngradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearngradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearngradleApplication.class, args);
	}

}
