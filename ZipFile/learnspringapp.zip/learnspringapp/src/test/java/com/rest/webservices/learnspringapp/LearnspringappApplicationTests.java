package com.rest.webservices.learnspringapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnspringappApplicationTests {

	@Test
	void contextLoads() {
	}

}
