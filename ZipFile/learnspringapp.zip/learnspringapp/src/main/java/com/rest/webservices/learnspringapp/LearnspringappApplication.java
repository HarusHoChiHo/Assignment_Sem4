package com.rest.webservices.learnspringapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnspringappApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnspringappApplication.class, args);
	}

}
