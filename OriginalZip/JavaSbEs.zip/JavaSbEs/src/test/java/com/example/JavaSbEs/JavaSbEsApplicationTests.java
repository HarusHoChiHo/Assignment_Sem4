package com.example.JavaSbEs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSbEsApplicationTests {

	@Test
	void contextLoads() {
	}

}
