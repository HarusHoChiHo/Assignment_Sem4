package com.example.JavaSbAg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSbAgApplicationTests {

	@Test
	void contextLoads() {
	}

}
