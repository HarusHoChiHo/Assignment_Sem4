package com.example.JavaSbAg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSbAgApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSbAgApplication.class, args);
	}

}
