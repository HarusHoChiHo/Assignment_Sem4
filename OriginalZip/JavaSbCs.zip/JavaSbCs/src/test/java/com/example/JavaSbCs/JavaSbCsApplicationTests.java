package com.example.JavaSbCs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSbCsApplicationTests {

	@Test
	void contextLoads() {
	}

}
