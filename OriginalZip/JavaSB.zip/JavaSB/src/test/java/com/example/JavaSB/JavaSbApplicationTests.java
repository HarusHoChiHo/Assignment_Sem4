package com.example.JavaSB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
